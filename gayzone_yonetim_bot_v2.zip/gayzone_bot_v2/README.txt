GAYZONE Telegram Moderation Bot

Features:
- Deletes Telegram join/leave/removal service messages.
- Deletes messages containing links when BLOCK_LINKS=true.
- Deletes messages containing any comma-separated term in BANNED_WORDS.
- Checks ordinary text and media captions.

Required environment variables:
- BOT_TOKEN: token from BotFather (keep private).
- WEBHOOK_SECRET: secret string used to verify Telegram webhook requests.
- BLOCK_LINKS: true or false (default true).
- BANNED_WORDS: comma-separated blocked words/phrases, e.g. kelime1,kelime2.

The bot must be an administrator in the group with permission to delete messages.
Do not publish BOT_TOKEN in GitHub or screenshots.
