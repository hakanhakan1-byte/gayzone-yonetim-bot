import os
import re
import requests
from fastapi import FastAPI, Request, HTTPException

TOKEN = os.environ["BOT_TOKEN"]
WEBHOOK_SECRET = os.environ["WEBHOOK_SECRET"]
BASE = f"https://api.telegram.org/bot{TOKEN}"
app = FastAPI()

# Configure these in the hosting service's Environment settings.
BLOCK_LINKS = os.getenv("BLOCK_LINKS", "true").lower() in {"1", "true", "yes", "on"}
BANNED_WORDS = [
    word.strip().casefold()
    for word in os.getenv("BANNED_WORDS", "").split(",")
    if word.strip()
]
LINK_PATTERN = re.compile(
    r"(?:https?://|www\.|t\.me/|telegram\.me/|telegram\.dog/)",
    re.IGNORECASE,
)


def telegram(method, payload):
    response = requests.post(f"{BASE}/{method}", json=payload, timeout=15)
    response.raise_for_status()
    data = response.json()
    if not data.get("ok"):
        raise RuntimeError(data)
    return data


@app.on_event("startup")
def register_webhook():
    public_url = os.environ.get("RENDER_EXTERNAL_URL")
    if public_url:
        telegram("setWebhook", {
            "url": f"{public_url}/telegram",
            "secret_token": WEBHOOK_SECRET,
            "allowed_updates": ["message"]
        })


@app.post("/telegram")
async def telegram_webhook(request: Request):
    if request.headers.get("X-Telegram-Bot-Api-Secret-Token") != WEBHOOK_SECRET:
        raise HTTPException(status_code=403, detail="Forbidden")

    update = await request.json()
    message = update.get("message", {})
    chat_id = message.get("chat", {}).get("id")
    message_id = message.get("message_id")
    if not chat_id or not message_id:
        return {"ok": True}

    # Remove Telegram service messages for joins, leaves and removals.
    is_service_message = (
        "new_chat_members" in message or "left_chat_member" in message
    )

    # Check regular text and captions (including media captions).
    text = message.get("text") or message.get("caption") or ""
    normalized = text.casefold()
    has_link = BLOCK_LINKS and bool(LINK_PATTERN.search(text))
    has_banned_word = any(word in normalized for word in BANNED_WORDS)

    if is_service_message or has_link or has_banned_word:
        telegram("deleteMessage", {
            "chat_id": chat_id,
            "message_id": message_id
        })

    return {"ok": True}


@app.get("/")
def health():
    return {"status": "GAYZONE moderation bot is running"}
